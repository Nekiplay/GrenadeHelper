
local font        = renderer.setup_font("C:/Windows/Fonts/verdana.ttf", 12, 0)
local notify =
    (function()
    local a = {callback_registered = false, maximum_count = 7, data = {}}
    function a:register_callback()
        if self.callback_registered then
            return
        end
        client.register_callback(
            "paint",
            function()
                local b = {engine.get_screen_size().x, engine.get_screen_size().y}
                local c = {56, 56, 57}
                local d = 5
                local e = self.data
                for f = #e, 1, -1 do
                    self.data[f].time = self.data[f].time - globalvars.get_frame_time()
                    local g, h = 255, 0
                    local i = e[f]
                    if i.time < 0 then
                        table.remove(self.data, f)
                    else
                        local j = i.def_time - i.time
                        local j = j > 1 and 1 or j
                        if i.time < 0.5 or j < 0.5 then
                            h = (j < 1 and j or i.time) / 0.5
                            g = h * 255
                            if h < 0.2 then
                                d = d + 15 * (1.0 - h / 0.2)
                            end
                        end
                        local k = {renderer.get_text_size(font, 12, i.draw).x, renderer.get_text_size(font, 12, i.draw).y}
                        local l = {b[1] / 2 - k[1] / 2 + 3, b[2] - b[2] / 100 * 17.4 + d}
                        renderer.circle(vec2_t.new(l[1], l[2]), 20, 180, true, color_t.new(c[1], c[2], c[3], g))
                        renderer.circle(vec2_t.new(l[1] + k[1], l[2]), 20, 180, true, color_t.new(c[1], c[2], c[3], g))
                        renderer.rect_filled(vec2_t.new(l[1], l[2] - 20), vec2_t.new(l[1] + k[1], l[2] - 20 + 40), color_t.new(c[1], c[2], c[3], g))
                        renderer.text(i.draw, font, vec2_t.new(l[1], l[2] - 6), 12, color_t.new(255, 255, 255, g))
                        d = d - 50
                    end
                end
                self.callback_registered = true
            end
        )
    end
    function a:paint(m, n)
        local o = tonumber(m) + 1
        for f = self.maximum_count, 2, -1 do
            self.data[f] = self.data[f - 1]
        end
        self.data[1] = {time = o, def_time = o, draw = n}
        self:register_callback()
    end
    return a
end)()
return {add = function(dur, text) notify:paint(dur, text) end}