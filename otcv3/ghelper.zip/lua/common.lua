function DrawRect(x, y, w, h, color, filled)
    if filled then 
        renderer.rect_filled(vec2_t.new(x, y), vec2_t.new(x + w, y + h), color)
    else
        renderer.rect(vec2_t.new(x, y), vec2_t.new(x + w, y + h), color)
    end
end

function FindMax(floats)
    local result = floats[1]
    for i = 1, #floats do
        local value = floats[i]
        if value > result then
            result = value
        end
    end
    return result
end

function FindMin(floats)
    local result = floats[1]
    for i = 1, #floats do
        local value = floats[i]
        if value < result then
            result = value
        end
    end
    return result
end

function ToRGBA(color)
    return color.r, color.g, color.b, color.a
end

function RGBToHSV(r, g, b, a)
    local r, g, b = r/255, g/255, b/255
    local max, min = FindMax({ r, g, b }), FindMin({ r, g, b })
    local h, s, v
    v = max
    if max == 0 then s = 0 else s = 1 - min / max end
    if max - min == 0 then
        h = 0
    elseif max == g then
        h = (b - r) * 60 / (max - min) + 120
    elseif max == b then
        h = (r - g) * 60 / (max - min) + 240
    else
        h = (g - b) * 60 / (max - min)
        if b > g then
            h = h + 360
        end
    end
    return h, s, v, a
end

function HSVToRGB(h, s, v, a)
    local r, g, b
    local c = v * s
    local x = c * (1 - math.abs((h / 60) % 2 - 1))
    local m = v - c
    if h < 60 then
        r, g, b = c, x, 0
    elseif h < 120 then
        r, g, b = x, c, 0
    elseif h < 180 then
        r, g, b = 0, c, x
    elseif h < 240 then
        r, g, b = 0, x, c
    elseif h < 300 then
        r, g, b = x, 0, c
    else
        r, g, b = c, 0, x
    end
    return (r + m)*255, (g + m)*255, (b + m)*255, a
end

function MouseIntoRect(x, y, w, h)
    local mouse = renderer.get_cursor_pos()
    if mouse.x > x and mouse.x < x + w and mouse.y > y and mouse.y < y + h then 
        return true 
    end
end

